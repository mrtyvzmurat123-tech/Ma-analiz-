# Football Predictor AI — MVP 0.1

Bu sürüm telefon uyumlu web uygulaması ve bağımsız Poisson olasılık hesaplayıcısıdır.

## Çalıştırma

Python 3.10+ kurulu olmalı.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS / Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload
```

Tarayıcıdan `http://127.0.0.1:8000` adresini aç.

## Bu sürüm ne yapar?
- Takım adları ve iki beklenen gol (xG) girdisiyle 1X2 olasılıkları hesaplar.
- 1.5 / 2.5 / 3.5 gol çizgileri, KG ve en olası beş skoru verir.
- Telefon ekranlarına uyumlu arayüze sahiptir.

## Henüz yapmadıkları
- Dünya liglerinin otomatik fikstürünü çekmez.
- Canlı skor, kadro, sakatlık, hakem ve hava durumu API'lerine bağlı değildir.
- Kullanıcının girdiği xG değerleri otomatik maç analizi değildir.
- İlk Poisson modeli kalibrasyon ve geçmiş maçlarla doğrulama yapılmadan gerçek tahmin başarısı iddia etmez.

## Sonraki geliştirme aşaması
1. Futbol veri sağlayıcısı seçimi ve API anahtarı.
2. Fikstür ve geçmiş maç verilerinin veritabanına alınması.
3. Takım gücü, iç saha avantajı, xG ve form özellikleri.
4. Kadro/sakatlık/hakem/hava verisi; kaynak ve güncelleme zamanı takibi.
5. Dixon–Coles / Poisson ve makine öğrenmesi modellerinin karşılaştırılması.
6. Zaman bazlı backtest, kalibrasyon, Brier score ve log loss raporları.
7. Canlı maç modeli ve mobil PWA iyileştirmeleri.

**Önemli:** %90+ doğruluk garanti edilemez. Model performansı lig ve tahmin pazarı bazında, görülmemiş maçlarda test edilmelidir.
