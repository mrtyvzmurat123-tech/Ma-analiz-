from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from math import exp, factorial
from pathlib import Path

BASE = Path(__file__).resolve().parent
app = FastAPI(title="Football Predictor AI", version="0.1.0")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

class PredictionRequest(BaseModel):
    home_team: str = Field(min_length=1, max_length=80)
    away_team: str = Field(min_length=1, max_length=80)
    home_xg: float = Field(ge=0.05, le=5.0)
    away_xg: float = Field(ge=0.05, le=5.0)

def poisson(lam: float, k: int) -> float:
    return exp(-lam) * (lam ** k) / factorial(k)

def calculate(home_xg: float, away_xg: float):
    max_goals = 10
    home = [poisson(home_xg, i) for i in range(max_goals + 1)]
    away = [poisson(away_xg, i) for i in range(max_goals + 1)]
    matrix = [[home[i] * away[j] for j in range(max_goals + 1)] for i in range(max_goals + 1)]

    p1 = sum(matrix[i][j] for i in range(max_goals + 1) for j in range(max_goals + 1) if i > j)
    px = sum(matrix[i][j] for i in range(max_goals + 1) for j in range(max_goals + 1) if i == j)
    p2 = sum(matrix[i][j] for i in range(max_goals + 1) for j in range(max_goals + 1) if i < j)
    over15 = sum(matrix[i][j] for i in range(max_goals + 1) for j in range(max_goals + 1) if i + j >= 2)
    over25 = sum(matrix[i][j] for i in range(max_goals + 1) for j in range(max_goals + 1) if i + j >= 3)
    over35 = sum(matrix[i][j] for i in range(max_goals + 1) for j in range(max_goals + 1) if i + j >= 4)
    btts = sum(matrix[i][j] for i in range(1, max_goals + 1) for j in range(1, max_goals + 1))
    scores = sorted(
        [{"score": f"{i}-{j}", "probability": matrix[i][j]}
         for i in range(max_goals + 1) for j in range(max_goals + 1)],
        key=lambda x: x["probability"], reverse=True
    )[:5]
    pct = lambda x: round(x * 100, 1)
    return {
        "result": {"home": pct(p1), "draw": pct(px), "away": pct(p2)},
        "totals": {
            "over_1_5": pct(over15), "under_1_5": pct(1-over15),
            "over_2_5": pct(over25), "under_2_5": pct(1-over25),
            "over_3_5": pct(over35), "under_3_5": pct(1-over35)
        },
        "btts": {"yes": pct(btts), "no": pct(1-btts)},
        "expected_goals": round(home_xg + away_xg, 2),
        "top_scores": [{**s, "probability": pct(s["probability"])} for s in scores]
    }

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"status": "ok", "version": "0.1.0", "data_provider": "not_configured"}

@app.get("/api/fixtures")
def fixtures():
    return {
        "status": "not_configured",
        "message": "Gerçek fikstürleri göstermek için bir futbol veri sağlayıcısı API anahtarı bağlanmalıdır.",
        "fixtures": []
    }

@app.post("/api/predict")
def predict(req: PredictionRequest):
    return {
        "home_team": req.home_team,
        "away_team": req.away_team,
        "model": "Independent Poisson baseline",
        "input_basis": "Kullanıcının girdiği beklenen gol (xG) değerleri",
        "warning": "Bu ilk prototipte xG değerleri otomatik toplanmaz. Sonuçlar gerçek maç verisiyle doğrulanmış tahmin değildir.",
        "predictions": calculate(req.home_xg, req.away_xg)
    }
